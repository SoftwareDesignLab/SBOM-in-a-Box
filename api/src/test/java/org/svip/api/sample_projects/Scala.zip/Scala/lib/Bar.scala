package Scala

case class Bar {

}